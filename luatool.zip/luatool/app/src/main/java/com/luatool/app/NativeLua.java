package com.luatool.app;

/** JNI wrapper around the embedded Lua 5.3 interpreter (libluatool.so). */
public final class NativeLua {
    private NativeLua() {}

    public interface Host {
        Object[] call(int id, Object[] args) throws Exception;
        void print(byte[] line);
    }

    public static volatile boolean available;
    public static volatile String loadError;
    static volatile Host host;

    static {
        try {
            System.loadLibrary("luatool");
            available = true;
        } catch (Throwable t) {
            available = false;
            loadError = String.valueOf(t);
        }
    }

    /** @return null on success, else the error message (UTF-8 bytes). Blocks until the script ends. */
    public static native byte[] run(byte[] code, String chunkName, String[] fnNames, Object[] consts, String prelude);

    public static native void stop();

    public static native String version();

    // ---- called from native code ----

    static Object[] callback(int id, Object[] args) {
        Host h = host;
        if (h == null) throw new IllegalStateException("no host");
        try {
            return h.call(id, args);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage() == null ? e.toString() : e.getMessage(), e);
        }
    }

    static void print(byte[] line) {
        Host h = host;
        if (h != null) h.print(line);
    }
}
