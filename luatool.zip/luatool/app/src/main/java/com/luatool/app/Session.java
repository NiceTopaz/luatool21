package com.luatool.app;

import android.content.Context;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.jse.JsePlatform;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.PrintStream;

/** Global state: selected process, running script, stop flag. */
public final class Session {
    private Session() {}

    public static volatile ProcessInfo target;
    public static volatile MemEngine engine;
    public static volatile boolean running;
    public static volatile boolean stopRequested;
    public static volatile File scriptFile;
    public static volatile Context app;

    // floating-button "click" support for scripts that poll gg.isClickedUiButton()
    public static volatile long lastClickPoll;
    public static volatile boolean clicked;

    private static Thread thread;

    /** @return null on success, else an error message. */
    public static synchronized String select(ProcessInfo p) {
        MemEngine old = engine;
        engine = null;
        if (old != null) old.close();
        target = p;
        MemEngine e = new MemEngine(p.pid);
        String err = e.open();
        if (err != null) {
            e.close();
            return err;
        }
        engine = e;
        return null;
    }

    public static void check() {
        if (stopRequested) throw new LuaError("script stopped");
    }

    public static synchronized void run(final File f) {
        if (running) {
            AppLog.add("A script is already running - press Stop first.");
            return;
        }
        final ProcessInfo t = target;
        final MemEngine eng = engine;
        if (t == null || eng == null) {
            AppLog.add("Select a process that opened successfully first.");
            return;
        }
        if (!new File("/proc/" + t.pid).exists()) {
            AppLog.add("That process has ended. Refresh the list and select it again.");
            return;
        }
        running = true;
        stopRequested = false;
        clicked = false;
        eng.cancel = false;
        scriptFile = f;
        thread = new Thread(null, new Runnable() {
            @Override public void run() {
                AppLog.add("Running " + f.getName() + " on " + t.name);
                try {
                    byte[] data = readBytes(f);
                    int bv = ScriptLoader.bytecodeVersion(data);
                    if (bv != -1 && bv != 0x52 && bv != 0x53) {
                        fail("This script is precompiled " + ScriptLoader.versionName(bv) + " bytecode (header: "
                                + ScriptLoader.headerHex(data) + "). LuaTool runs Lua 5.3 bytecode, Lua 5.2 bytecode and any "
                                + "plain-text script - it cannot run " + ScriptLoader.versionName(bv) + " bytecode.");
                    } else if (NativeLua.available && bv != 0x52) {
                        runNative(f, data, eng);
                    } else {
                        AppLog.add(bv == 0x52 ? "Engine: LuaJ (Lua 5.2 bytecode)"
                                : "Engine: LuaJ (Lua 5.2) - native Lua 5.3 not loaded: " + NativeLua.loadError);
                        Globals g = JsePlatform.standardGlobals();
                        g.STDOUT = new PrintStream(new LogOut(), true);
                        g.set("luajava", LuaValue.NIL);   // no raw Java access from scripts
                        Compat.install(g);
                        g.load(Compat.LUA, "=compat").call();   // Lua 5.1/LuaJIT compatibility (loadstring, unpack, setfenv...)
                        g.set("gg", GgApi.install(f));
                        LuaValue chunk = ScriptLoader.load(g, data, f.getName());
                        chunk.call();
                        AppLog.add("Script finished." + (eng.frozenCount() > 0 ? " (" + eng.frozenCount() + " values frozen - Stop clears them)" : ""));
                    }
                } catch (LuaError e) {
                    if (stopRequested) AppLog.add("Script stopped.");
                    else fail("Lua error: " + e.getMessage());
                } catch (StackOverflowError e) {
                    fail("Script error: stack overflow (script recurses too deeply for this engine)");
                } catch (Throwable e) {
                    if (stopRequested || e instanceof MemEngine.Cancelled) AppLog.add("Script stopped.");
                    else fail("Error: " + e);
                } finally {
                    running = false;
                }
            }
        }, "lua-script", 64L * 1024 * 1024);   // big stack: obfuscated scripts nest very deeply
        thread.setDaemon(true);
        thread.start();
    }

    private static void runNative(File f, byte[] data, MemEngine eng) {
        AppLog.add("Engine: " + NativeLua.version() + " (native)");
        NativeLua.host = new GgNative(f);
        byte[] err = NativeLua.run(data, "@" + f.getName(), GgNative.names(), GgNative.constants(), Prelude.LUA);
        if (err == null) {
            AppLog.add("Script finished." + (eng.frozenCount() > 0 ? " (" + eng.frozenCount() + " values frozen - Stop clears them)" : ""));
        } else {
            String m;
            try { m = new String(err, "UTF-8"); } catch (Exception ex) { m = "error"; }
            if (m.contains("version mismatch in precompiled chunk"))
                m += "\n(the script is bytecode of a different Lua version; header: " + ScriptLoader.headerHex(data) + ")";
            if (stopRequested || m.contains("script stopped")) AppLog.add("Script stopped.");
            else fail("Lua error: " + m);
        }
    }

    public static void stop() {
        if (NativeLua.available && running) NativeLua.stop();
        MemEngine e = engine;
        if (e != null) {
            e.cancel = true;
            e.clearFreeze();
        }
        if (running) {
            stopRequested = true;
            Thread t = thread;
            if (t != null) t.interrupt();
            AppLog.add("Stopping...");
        } else {
            AppLog.add("Stopped (frozen values cleared).");
        }
    }

    /** Errors must be visible even when the panel is closed. */
    static void fail(String msg) {
        AppLog.add(msg);
        String shown = msg.length() > 300 ? msg.substring(0, 300) + "..." : msg;
        UiBridge.toast(shown, false);
    }

    static byte[] readBytes(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
        }
    }

    static String readUtf8(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toString("UTF-8");
        } finally {
            in.close();
        }
    }

    /** Routes Lua print() to the panel log. */
    private static final class LogOut extends OutputStream {
        private final ByteArrayOutputStream buf = new ByteArrayOutputStream();

        @Override public void write(int b) {
            if (b == '\n') flushLine();
            else if (b != '\r') buf.write(b);
        }

        private void flushLine() {
            try { AppLog.add(buf.toString("UTF-8")); } catch (Exception ignored) {}
            buf.reset();
        }
    }
}
